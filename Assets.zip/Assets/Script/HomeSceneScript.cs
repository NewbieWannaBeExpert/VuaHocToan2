using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class HomeSceneScript : MonoBehaviour
{
    
    void Start()
    {

        GameObject btnToHocSo = transform.GetChild(1).gameObject;
        GameObject gToHocSo = Instantiate(btnToHocSo, transform);
        gToHocSo.GetComponent<Button>().onClick.AddListener(delegate ()
        {
            ToHocSo();
        });
        Destroy(btnToHocSo);
        GameObject btnLamToan = transform.GetChild(2).gameObject;
        btnLamToan.GetComponent<Button>().onClick.AddListener(delegate ()
        {
            ToLamToan();
        });
    }

    void ToHocSo()
    {
        Debug.Log("ToHoc so clicked");
        SceneManager.LoadScene("Scenes/HocSoHomeScene");
    }
    void ToLamToan()
    {
        SceneManager.LoadScene("Scenes/LamToanHomeScene");
    }

}
