using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HomeSoScript : MonoBehaviour
{
    public AudioSource audioSource;
    public static AudioClip buttonClickSound;
    // Start is called before the first frame update
    void Start()
    {
        buttonClickSound = Resources.Load<AudioClip>("Sound/aButtonClicked") as AudioClip;
        GameObject btnToHocSo = transform.GetChild(2).gameObject;
        GameObject gToHocSo = Instantiate(btnToHocSo, transform);
        gToHocSo.GetComponent<Button>().onClick.AddListener(delegate ()
        {
            ToHocSo();
        });

        GameObject btnToHome = transform.GetChild(1).gameObject;
        GameObject gToHome = Instantiate(btnToHome, transform);
        gToHome.GetComponent<Button>().onClick.AddListener(delegate ()
        {
            ToHome();
        });

        Destroy(btnToHocSo);
        Destroy(btnToHome);
    }

    void ToHocSo()
    {
        Debug.Log("To List scene clicked");
        SceneManager.LoadScene("Scenes/ListScene");
    }
    void ToHome()
    {
        SceneManager.LoadScene("Scenes/HomeScene");
    }

}
